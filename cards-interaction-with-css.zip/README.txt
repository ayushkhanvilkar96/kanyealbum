A Pen created at CodePen.io. You can find this one at https://codepen.io/dhanishgajjar/pen/WjJJrg.

 Another experiment, with just CSS. There is a lot I want to add, but may be later. I keep messing things up, when I try to add more animations. Hope you like it and learn from it.